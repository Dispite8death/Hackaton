import asyncio
import json
from datetime import datetime,timedelta
import httpx
import pytest
from fastapi.testclient import TestClient
from app import store,intelligence
from app.crawler import extract_html,clean_url,public_url,Crawler
from app.rules import audit,date_value,publication,LOCAL
from app.main import app,SESSION,next_schedule,csv_value

ORG={'id':1,'name':'Проверочная школа','url':'https://school.example/','kind':'school'}
AT=datetime(2026,11,7,12,tzinfo=LOCAL)
def crawl(pages=None):return {'pages':pages or [],'errors':[],'documents':[],'limited':False}

def page(text='Сведения школы '*30,sections=None,**kwargs):
    return dict(url='https://school.example/news/one/',title='Новости',text=text,sections=sections or ['news'],published=[],links=[],images=[],**kwargs)

def test_unavailable_is_never_violation():
    result=audit(ORG,crawl(),{'state':'disabled'},AT)
    assert result['status']=='unavailable'
    assert result['score'] is None and result['coverage']==0
    assert not any(c['status']=='fail' for c in result['checks'])

def test_dates_russian_iso_invalid_and_timezone():
    assert date_value('7 ноября 2026').day==7
    assert date_value('2026-11-07T01:20:00Z').hour==1
    assert date_value('31.02.2026') is None
    assert date_value('07.11.2026').utcoffset()==timedelta(hours=11)

def test_publication_does_not_use_event_date_or_footer_year():
    p=page('Событие состоялось 10.10.2026. Все права защищены 2026')
    assert publication(p)==(None,'')
    p['published']=['2026-11-01','2026-10-01']
    assert publication(p)==(None,'')
    p['published']=['2026-11-01T12:00:00+11:00']
    assert publication(p)[0].day==1

def test_missing_interval_is_review_not_false_violation():
    a=page();a['published']=['2026-11-06'];b=page();b['url']='https://school.example/news/two/';b['published']=['2026-10-01']
    result=audit(ORG,crawl([a,b]),{'state':'disabled'},AT)
    gap=next(c for c in result['checks'] if c['key']=='news_gap')
    assert gap['status']=='review' and '36' in gap['title']
    assert next(c for c in result['checks'] if c['key']=='news_24h')['status']=='unknown'

def test_quarter_rollover_and_kind_checklists():
    result=audit(ORG,crawl([page()]),{'state':'disabled'},AT)
    assert '01.2027' in next(c for c in result['checks'] if c['key']=='events_next')['title']
    other=audit(dict(ORG,kind='kindergarten'),crawl([page()]),{'state':'disabled'},AT)
    keys={c['key'] for c in other['checks']}
    assert 'section_programs' in keys and 'section_employees' in keys and 'section_schedule' not in keys

def test_html_main_not_navigation_and_safe_links():
    p=extract_html('<html><title>Школа</title><body><nav>Контакты: нет</nav><main><h1>Новости</h1><p>Реальный текст</p><a href="/files/a.pdf">Устав</a><a href="javascript:alert(1)">x</a><time datetime="2026-11-01">1 ноября</time></main></body></html>','https://school.example/')
    assert 'Контакты: нет' not in p['text']
    assert p['published']==['2026-11-01']
    assert len(p['links'])==1
    assert p['links'][0]['url']=='https://school.example/files/a.pdf'

def test_gosweb_kindergarten_caption_not_event_body():
    p=extract_html('<main><h1>Ходили в музей</h1><div class="gw-content-small-title">26 октября 2026 г.</div><p>Событие состоялось 23 октября 2026 г.</p></main>','https://school.example/nash-detskiy-sad/novosti-i-sobytiya/novosti_599.html')
    assert p['published']==['26 октября 2026 г.']
    assert publication(p)[0].day==26

def test_file_not_found_is_confirmed_error():
    data=crawl([page()]);data['documents']=[{'url':'https://school.example/doc.pdf','source':ORG['url'],'text':'Устав','state':'error','http_status':404,'error':'HTTP 404'}]
    result=audit(ORG,data,{'state':'disabled'},AT)
    assert any(c['status']=='fail' and '404' in c['title'] for c in result['checks'])

def test_private_urls_and_bad_schemes_rejected():
    for url in ['javascript:alert(1)','file:///c:/secret','https://user:pass@example.com','https://example.com:5000']:
        with pytest.raises(ValueError):clean_url(url)
    with pytest.raises(ValueError):asyncio.run(public_url('http://127.0.0.1/'))

def test_llm_hallucination_rejected_and_claims_require_human(monkeypatch):
    async def sources(*args):return [],[]
    async def completion(*args):return {'findings':[
        {'url':'https://forged.example/','quote':'Несуществующая цитата'},
        {'url':'https://school.example/news/one/','quote':'Реальный текст данных школы','title':'Проверить сведения','status':'fail','severity':'high','recommendation':'Уточнить'}], 'events':[]}
    monkeypatch.setattr(intelligence,'external_evidence',sources);monkeypatch.setattr(intelligence,'complete',completion)
    data=asyncio.run(intelligence.analyze(crawl([page('Реальный текст данных школы и другая информация')]),{'llm_enabled':True},'school'))
    assert data['rejected']==1 and len(data['findings'])==1
    assert data['findings'][0]['status']=='review'

def test_llm_failure_does_not_erase_rule_report(monkeypatch):
    async def sources(*args):return [],[]
    async def broken(*args):raise ValueError('bad JSON')
    monkeypatch.setattr(intelligence,'external_evidence',sources);monkeypatch.setattr(intelligence,'complete',broken)
    ai=asyncio.run(intelligence.analyze(crawl([page()]),{'llm_enabled':True},'school'))
    result=audit(ORG,crawl([page()]),ai,AT)
    assert ai['state']=='error' and len(result['checks'])>10

def test_schedule_and_csv_injection():
    cfg=dict(schedule_hour=8,schedule_interval_days=7)
    assert datetime.fromisoformat(next_schedule(cfg,AT)).day==14
    assert csv_value('=CMD()').startswith("'")
    assert csv_value('обычный текст')=='обычный текст'

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(store,'DB',tmp_path/'test.sqlite3')
    with TestClient(app) as c:yield c

def test_api_seed_secrets_persistence_and_validation(client):
    s=client.get('/api/state').json();assert len(s['organizations'])==80
    assert 'api_key' not in s['settings']
    assert client.put('/api/settings',json={}).status_code==403
    h={'X-Audit-Session':s['session']}
    assert client.put('/api/settings',json={'max_pages':0},headers=h).status_code==422
    assert client.put('/api/settings',json={'api_key':'test-secret','max_pages':42},headers=h).status_code==200
    saved=client.get('/api/state').json()['settings'];assert saved['has_api_key'] and saved['max_pages']==42
    assert 'test-secret' not in client.get('/api/state').text
    assert client.post('/api/organizations',json=dict(name='Новая школа',url='https://new.example/',kind='school'),headers=h).status_code==200
    assert len(client.get('/api/state').json()['organizations'])==81
    assert client.post('/api/organizations',json=dict(name='Новая школа',url='https://new.example/',kind='school'),headers=h).status_code==409
    assert client.post('/api/runs',json={},headers=dict(h,Origin='https://evil.example')).status_code==403

def test_report_roundtrip_export_reviews_and_reference(client):
    d=audit(ORG,crawl([page()]),{'state':'disabled'},AT)
    with store.connect() as db:
        cur=db.execute('INSERT INTO reports(run_id,org_id,created,data) VALUES(?,?,?,?)',('test',1,store.now(),json.dumps(d,ensure_ascii=False)))
        rid=cur.lastrowid
    saved=client.get(f'/api/reports/{rid}').json();assert saved['data']['checks']==d['checks']
    h={'X-Audit-Session':SESSION};fingerprint=d['checks'][0]['fingerprint']
    assert client.put('/api/reviews/'+fingerprint,json={'state':'fixed','note':'Проверено'},headers=h).status_code==200
    assert client.get(f'/api/reports/{rid}').json()['reviews'][fingerprint]['state']=='fixed'
    for fmt in ('json','csv','html'):assert client.get(f'/api/reports/{rid}/export/{fmt}').status_code==200
    assert 'Проверено' in client.get(f'/api/reports/{rid}/export/csv').text
    assert 'Исправлено' in client.get(f'/api/reports/{rid}/export/html').text
    assert client.get(f'/api/reports/{rid}/export/json').json()['reviews'][fingerprint]['state']=='fixed'
    assert 'window.print()' in client.get(f'/api/reports/{rid}/export/html').text
    assert client.get('/api/comparison').json()[0]['reference'] is None
    assert client.put('/api/settings',json={'benchmark_school':1},headers=h).status_code==200
    assert client.get('/api/comparison').json()[0]['reference']['org_id']==1

def test_crawl_links_robots_documents_and_limits(monkeypatch):
    async def safe(u):return u
    monkeypatch.setattr('app.crawler.public_url',safe)
    fixtures={
        'https://school.example/robots.txt':b'User-agent: *\nDisallow: /private',
        'https://school.example/sitemap.xml':b'<urlset><url><loc>https://school.example/news/</loc></url></urlset>',
        'https://school.example/':('<main><h1>School</h1><p>'+('content '*30)+'</p><a href="/news/">Новости</a><a href="/private">Данные</a><a href="/doc.pdf">Устав</a></main>').encode(),
        'https://school.example/news/':b'<main><h1>News</h1><a href="/news/one/">Publication</a></main>',
        'https://school.example/news/one/':b'<main><h1>Event</h1><time datetime="2026-11-01">Date</time></main>'}
    async def fetch(self,client,url,max_bytes=6000000):
        if url.endswith('doc.pdf'):raise ValueError('Unparseable fixture document')
        return fixtures[url], 'text/html',url,'utf-8'
    monkeypatch.setattr(Crawler,'fetch',fetch)
    cfg=dict(store.DEFAULTS,max_pages=10,request_delay=0)
    result=asyncio.run(Crawler(cfg).crawl('https://school.example/'))
    assert len(result['pages'])==3 and len(result['documents'])==1
    assert any(e['kind']=='robots' for e in result['errors'])
    assert 'news' in result['pages'][-1]['sections']

def test_run_lifecycle_saves_report_and_blocks_overlap(client,monkeypatch):
    gate=asyncio.Event()
    async def fake_crawl(self,url):
        await asyncio.sleep(0.06)
        return crawl([page()])
    monkeypatch.setattr(Crawler,'crawl',fake_crawl)
    headers={'X-Audit-Session':SESSION}
    run=client.post('/api/runs',json={'organization_ids':[1]},headers=headers)
    assert run.status_code==200
    assert client.post('/api/runs',json={'organization_ids':[2]},headers=headers).status_code==409
    import time
    for _ in range(100):
        data=client.get('/api/state').json()
        if data['runs'][0]['status']=='completed':break
        time.sleep(0.01)
    assert data['runs'][0]['done']==1 and data['runs'][0]['status']=='completed'
    assert len(client.get('/api/reports').json())==1

def test_cancel_preserves_finished_reports(client,monkeypatch):
    async def fake_crawl(self,url):
        await asyncio.sleep(0.5)
        return crawl([page()])
    monkeypatch.setattr(Crawler,'crawl',fake_crawl)
    headers={'X-Audit-Session':SESSION}
    result=client.post('/api/runs',json={'organization_ids':[1,2]},headers=headers).json()
    assert client.post('/api/runs/'+result['id']+'/cancel',headers=headers).status_code==200
    import time
    for _ in range(100):
        data=client.get('/api/state').json()
        if data['runs'][0]['status']=='cancelled':break
        time.sleep(0.01)
    assert data['runs'][0]['status']=='cancelled'

def test_openai_wire_protocol_and_model_discovery(monkeypatch):
    original=httpx.AsyncClient
    calls=[]
    def handler(request):
        calls.append(request)
        if request.url.path=='/v1/models':return httpx.Response(200,json={'data':[{'id':'local-model'}]})
        payload=json.loads(request.content)
        assert payload['model']=='local-model' and payload['stream'] is False
        assert request.headers['authorization']=='Bearer secret-fixture'
        return httpx.Response(200,json={'choices':[{'message':{'content':'```json\n{"ok":true}\n```'}}]})
    monkeypatch.setattr(intelligence.httpx,'AsyncClient',lambda **kw:original(transport=httpx.MockTransport(handler),**kw))
    result=asyncio.run(intelligence.complete({'base_url':'http://localhost:11434/v1','model':'','api_key':'secret-fixture'},[{'role':'user','content':'test'}]))
    assert result=={'ok':True} and len(calls)==2

def test_parallel_crawl_budget_checkpoint_and_quick_inventory(monkeypatch):
    async def safe(url):return url
    monkeypatch.setattr('app.crawler.public_url',safe)
    active=0;peak=0;document_fetches=[];checkpoints=[]
    async def fetch(self,client,url,max_bytes=6000000):
        nonlocal active,peak
        if url.endswith('robots.txt'):return b'User-agent: *','text/plain',url,'utf-8'
        if url.endswith('sitemap.xml'):return b'<urlset/>','application/xml',url,'utf-8'
        if url.endswith('.pdf'):document_fetches.append(url);raise AssertionError('Quick inventory must not download files')
        active+=1;peak=max(peak,active)
        await asyncio.sleep(.02)
        active-=1
        links=''.join(f'<a href="/news/{i}/">news {i}</a>' for i in range(20))
        return ('<main><h1>Новости</h1>'+links+'<a href="/file.pdf">Устав</a></main>').encode(),'text/html',url,'utf-8'
    async def checkpoint(data):checkpoints.append((len(data['pages']),len(data['documents'])))
    monkeypatch.setattr(Crawler,'fetch',fetch)
    cfg=dict(store.DEFAULTS,max_pages=9,max_documents=0,page_concurrency=4,request_delay=0)
    result=asyncio.run(Crawler(cfg,checkpoint=checkpoint).crawl('https://school.example/'))
    assert len(result['pages'])==9 and peak==4
    assert checkpoints==[(9,1)] and not document_fetches
    assert result['documents'][0]['state']=='deferred' and result['limited']

def test_missing_file_no_retry_and_host_rate_is_respected(monkeypatch):
    async def safe(url):return url
    monkeypatch.setattr('app.crawler.public_url',safe)
    calls=[]
    async def handler(request):
        import time
        calls.append(time.perf_counter())
        return httpx.Response(404)
    async def run():
        worker=Crawler(dict(store.DEFAULTS,request_delay=.02))
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            result=await asyncio.gather(*(worker.fetch(client,'https://school.example/missing.pdf') for _ in range(3)),return_exceptions=True)
        assert all(isinstance(e,httpx.HTTPStatusError) for e in result)
        assert worker.metrics['requests']==3 and worker.metrics['retries']==0
    asyncio.run(run())
    assert len(calls)==3 and all(b-a>=.018 for a,b in zip(calls,calls[1:]))

def test_preliminary_report_updates_without_changing_id(client,monkeypatch):
    async def fake_crawl(self,url):
        data=crawl([page()])
        await self.checkpoint(data)
        await asyncio.sleep(.15)
        return data
    monkeypatch.setattr(Crawler,'crawl',fake_crawl)
    h={'X-Audit-Session':SESSION}
    result=client.post('/api/runs',json={'organization_ids':[1]},headers=h)
    assert result.status_code==200
    import time
    for _ in range(100):
        records=client.get('/api/reports').json()
        if records:break
        time.sleep(.005)
    initial_id=records[0]['id'];assert records[0]['preliminary']
    for _ in range(100):
        records=client.get('/api/reports').json()
        if not records[0]['preliminary']:break
        time.sleep(.005)
    assert records[0]['id']==initial_id and not records[0]['preliminary']

def test_quick_mode_is_explicit_and_does_not_change_saved_settings(client,monkeypatch):
    seen=[]
    async def fake_crawl(self,url):
        seen.append(dict(self.cfg));return crawl([page()])
    monkeypatch.setattr(Crawler,'crawl',fake_crawl)
    h={'X-Audit-Session':SESSION}
    response=client.post('/api/runs',json={'organization_ids':[1],'mode':'quick'},headers=h)
    assert response.status_code==200
    import time
    for _ in range(100):
        if seen:break
        time.sleep(.005)
    assert seen[0]['max_pages']==24 and seen[0]['max_documents']==0 and not seen[0]['search_enabled']
    assert client.get('/api/state').json()['settings']['max_pages']==60

def test_cached_summary_avoids_loading_report_bodies(client):
    d=audit(ORG,crawl([page()]),{'state':'disabled'},AT)
    summary=store.summarize(d)
    with store.connect() as db:
        db.execute('INSERT INTO reports(run_id,org_id,created,data,summary) VALUES(?,?,?,?,?)',('cached',1,store.now(),'not JSON deliberately',json.dumps(summary)))
    assert client.get('/api/state').status_code==200
    assert client.get('/api/reports').json()[0]['name']==ORG['name']

def test_pacing_wait_is_not_counted_as_network_timeout(monkeypatch):
    async def safe(url):return url
    monkeypatch.setattr('app.crawler.public_url',safe)
    async def run():
        worker=Crawler(dict(store.DEFAULTS,request_delay=.04,timeout=.01))
        async with httpx.AsyncClient(transport=httpx.MockTransport(lambda request:httpx.Response(200,content=b'ok'))) as client:
            results=await asyncio.gather(*(worker.fetch(client,'https://school.example/') for _ in range(2)))
        assert all(r[0]==b'ok' for r in results)
    asyncio.run(run())
