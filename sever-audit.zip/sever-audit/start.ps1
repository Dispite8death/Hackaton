param([int]$Port = 8765, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$venvPython = Join-Path $PSScriptRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
    $runtimeCandidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs/Python/Python313/python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs/Python/Python312/python.exe'),
        (Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
    )
    $pythonLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($pythonLauncher) {
        & $pythonLauncher.Source -3 -m venv .venv
    } else {
        $pythonRuntime = $runtimeCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
        if (-not $pythonRuntime) {
            $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
            if ($pythonCommand -and $pythonCommand.Source -notmatch 'WindowsApps') { $pythonRuntime = $pythonCommand.Source }
        }
        if (-not $pythonRuntime) { throw 'Install Python 3.11+ from https://www.python.org/downloads/ and run again.' }
        & $pythonRuntime -m venv .venv
    }
    if ($LASTEXITCODE -ne 0) { throw 'Could not create Python environment.' }
}
$requirementsHash = (Get-FileHash -LiteralPath requirements.txt -Algorithm SHA256).Hash
$stampPath = Join-Path $PSScriptRoot '.venv/requirements.sha256'
$installedHash = if (Test-Path -LiteralPath $stampPath) { Get-Content -LiteralPath $stampPath -Raw } else { '' }
if ($installedHash.Trim() -ne $requirementsHash) {
    & $venvPython -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'Dependencies could not be installed. Check Internet connection and retry.' }
    Set-Content -LiteralPath $stampPath -Value $requirementsHash -NoNewline
}
$existing = $false
try {
    $health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 2
    $existing = $health.status -eq 'ok' -and $health.version -eq '1.0.0'
} catch { }
if ($existing) {
    if (-not $NoBrowser) { Start-Process "http://127.0.0.1:$Port" }
    Write-Host "Sever is already running: http://127.0.0.1:$Port"
    exit 0
}
Write-Host "Sever: http://127.0.0.1:$Port   Stop: Ctrl+C"
if (-not $NoBrowser) { Start-Process "http://127.0.0.1:$Port" }
& $venvPython -m uvicorn app.main:app --host 127.0.0.1 --port $Port --workers 1
