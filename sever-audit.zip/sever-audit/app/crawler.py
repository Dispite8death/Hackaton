import asyncio
import io
import ipaddress
import re
import socket
import zipfile
import hashlib
import time
from urllib.parse import urljoin, urlsplit, urlunsplit, parse_qsl, urlencode
from urllib.robotparser import RobotFileParser
from collections import deque
from datetime import datetime
import httpx
from bs4 import BeautifulSoup
from pypdf import PdfReader
from docx import Document

AGENT='SeverAudit/1.0 (+educational content quality audit)'
SECTIONS={
 'news':('новост','news','novosti'), 'events':('мероприят','событи','event','meropriyati','sobyt'),
 'documents':('документ','documents','сведения об образовательной','sveden'),
 'schedule':('расписан','schedule','raspisan'), 'about':('о школе','об учреждении','истори','about','o-shkole','istoriya'),
 'structure':('структур','органы управления','struct'),
 'staff':('педагогический состав','педагог','наш коллектив','руководств','учител','воспитател','employees'),
 'contacts':('контакт','contacts','kontakty'), 'programs':('образовательные программы','образовани','education','obrazovanie','obrazovatelnye-programmy'),
 'employees':('педагогам и сотрудникам','повышение квалификации','sotrudnik'),
 'useful':('полезная информация','учебник','вакант','стипенди','поддержк')}
DOC_EXT=('.pdf','.docx','.doc','.xls','.xlsx','.rtf','.odt','.sig')

def clean_url(url):
    p=urlsplit(url)
    if p.scheme not in ('http','https') or not p.hostname or p.username or p.password: raise ValueError('Нужен HTTP(S)-адрес без логина и пароля')
    if p.port and p.port not in (80,443): raise ValueError('Для сайтов разрешены порты 80 и 443')
    query=urlencode([(k,v) for k,v in parse_qsl(p.query) if not k.startswith(('utm_','yclid','gclid'))])
    return urlunsplit((p.scheme,p.netloc,p.path or '/',query,''))

async def public_url(url):
    url=clean_url(url)
    host=urlsplit(url).hostname
    infos=await asyncio.get_running_loop().getaddrinfo(host,None,type=socket.SOCK_STREAM)
    if not infos or any(not ipaddress.ip_address(i[4][0]).is_global for i in infos):
        raise ValueError('Адрес сайта должен вести в общедоступную сеть')
    return url

def classify(title,url=''):
    text=(title+' '+url).lower()
    return [k for k,words in SECTIONS.items() if any(w in text for w in words)]

def extract_html(html,url):
    soup=BeautifulSoup(html,'lxml')
    title=soup.title.get_text(' ',strip=True) if soup.title else url
    h1=soup.find('h1')
    if h1: title=h1.get_text(' ',strip=True)
    links=[]
    for a in soup.select('a[href]'):
        try:
            href=clean_url(urljoin(url,a['href']))
            links.append({'url':href,'text':a.get_text(' ',strip=True) or a.get('title','')})
        except (ValueError,TypeError): pass
    images=[{'src':urljoin(url,i.get('src','')),'alt':i.get('alt',''),'width':i.get('width'),'height':i.get('height')} for i in soup.select('img[src]')]
    published=[]
    for el in soup.select('time[datetime],meta[property="article:published_time"],meta[itemprop="datePublished"],[itemprop="datePublished"]'):
        value=el.get('datetime') or el.get('content') or el.get_text(' ',strip=True)
        if value: published.append(value)
    # Gosweb kindergarten articles expose the publication date as a caption below h1,
    # without time/meta elements. Only use standalone date captions on article URLs.
    if re.search(r'/novosti[^/]*/[^/]+\.html$',urlsplit(url).path):
        for el in soup.select('.gw-content-small-title'):
            value=el.get_text(' ',strip=True)
            if re.fullmatch(r'\d{1,2}\s+[а-я]+\s+20\d{2}\s*(?:г\.)?',value,re.I): published.append(value)
    main=soup.select_one('main') or soup.select_one('[role="main"]') or soup.select_one('.content') or soup.body or soup
    for el in main.select('script,style,noscript,nav,footer,header,aside'): el.decompose()
    text=re.sub(r'\s+',' ',main.get_text(' ',strip=True)).strip()
    headings=[h.get_text(' ',strip=True) for h in main.select('h1,h2,h3,h4')]
    return {'url':url,'title':title,'text':text[:70000],'links':links,'images':images,'published':published,
        'headings':headings,'sections':classify(title,url),'content_type':'html'}

class Crawler:
    """Bounded concurrent crawler. Requests to a host are paced by start time.

    One coordinator owns the frontier; independent requests overlap while redirects,
    robots directives, byte limits and the selected page budget remain enforced.
    """
    def __init__(self,config,cancel=lambda:False,progress=None,checkpoint=None):
        self.cfg=config; self.cancel=cancel; self.progress=progress; self.checkpoint=checkpoint
        self.pages=[]; self.errors=[]; self.documents=[]; self.limited=False; self.robots=None
        self._gates={}; self._slots={}; self._spacing=float(config.get('request_delay',.4))
        self.metrics={'requests':0,'retries':0,'page_seconds':0,'document_seconds':0}

    async def _pace(self,url):
        host=urlsplit(url).hostname
        lock=self._gates.setdefault(host,asyncio.Lock())
        async with lock:
            while (delay:=self._slots.get(host,0)-time.perf_counter())>0:
                await asyncio.sleep(max(delay,.001))
            self._slots[host]=time.perf_counter()+self._spacing

    async def fetch(self,client,url,max_bytes=6_000_000):
        for attempt in range(2):
            try:
                current=url
                for _ in range(6):
                    await public_url(current)
                    await self._pace(current)
                    self.metrics['requests']+=1
                    # Queue/robots waiting is not a network timeout.
                    async with asyncio.timeout(self.cfg.get('timeout',18)):
                        async with client.stream('GET',current,follow_redirects=False) as r:
                            if r.status_code in (301,302,303,307,308):
                                current=clean_url(urljoin(current,r.headers.get('location','')));continue
                            r.raise_for_status()
                            data=bytearray()
                            async for chunk in r.aiter_bytes():
                                data.extend(chunk)
                                if len(data)>max_bytes:raise ValueError(f'Файл превышает лимит {max_bytes//1_000_000} МБ')
                            return bytes(data),r.headers.get('content-type',''),current,r.encoding or 'utf-8'
                raise ValueError('Слишком много перенаправлений')
            except (httpx.HTTPError,OSError,ValueError,TimeoutError) as e:
                transient=isinstance(e,httpx.ConnectError) or isinstance(e,httpx.HTTPStatusError) and (e.response.status_code==429 or e.response.status_code>=500)
                if attempt or not transient:raise
                self.metrics['retries']+=1
                await asyncio.sleep(.3)

    def snapshot(self):
        return {'pages':self.pages,'documents':self.documents,'errors':self.errors,
            'limited':self.limited,'cancelled':self.cancel(),'metrics':dict(self.metrics)}

    def _notify(self,label):
        if self.progress:self.progress(len(self.pages),label)

    async def _read_document(self,client,d,host):
        if urlsplit(d['url']).hostname!=host:d['state']='external';return
        if self.robots and not self.robots.can_fetch(AGENT,d['url']):d['state']='robots';return
        if not urlsplit(d['url']).path.lower().endswith(('.pdf','.docx')):
            d['state']='manual';return
        try:
            raw,ctype,_,_=await self.fetch(client,d['url'])
            def parse():
                if 'pdf' in ctype or urlsplit(d['url']).path.lower().endswith('.pdf'):
                    reader=PdfReader(io.BytesIO(raw))
                    return ' '.join(p.extract_text() or '' for p in reader.pages[:35])
                with zipfile.ZipFile(io.BytesIO(raw)) as z:
                    if sum(i.file_size for i in z.infolist())>30_000_000:raise ValueError('Слишком большой распакованный документ')
                doc=Document(io.BytesIO(raw))
                return ' '.join(p.text for p in doc.paragraphs)
            text=await asyncio.to_thread(parse)
            d['text']=text[:25000];d['state']='read' if text.strip() else 'manual'
        except Exception as e:
            d['state']='error';d['error']=str(e)[:160] or type(e).__name__
            if isinstance(e,httpx.HTTPStatusError):d['http_status']=e.response.status_code

    async def crawl(self,start):
        import time
        started=time.perf_counter()
        start=clean_url(start);host=urlsplit(start).hostname
        frontier={start:(0,[])};visited=set();document_urls=set()
        max_pages=int(self.cfg['max_pages'])
        parallel=max(1,min(int(self.cfg.get('page_concurrency',4)),6))
        pending={}
        quotas={'news':8,'events':5,'staff':4,'employees':3,'documents':6}
        limits=httpx.Limits(max_connections=parallel+2,max_keepalive_connections=parallel+2)
        async with httpx.AsyncClient(timeout=self.cfg['timeout'],headers={'User-Agent':AGENT},limits=limits,trust_env=True) as client:
            self._notify('Правила обхода')
            try:
                raw,_,_,enc=await self.fetch(client,urljoin(start,'/robots.txt'),500_000)
                self.robots=RobotFileParser();self.robots.parse(raw.decode(enc,errors='replace').splitlines())
                self._spacing=max(self._spacing,self.robots.crawl_delay(AGENT) or 0)
                rate=self.robots.request_rate(AGENT)
                if rate and rate.requests:self._spacing=max(self._spacing,rate.seconds/rate.requests)
            except Exception as e:
                self.errors.append({'url':urljoin(start,'/robots.txt'),'error':'robots.txt не получен: '+(str(e) or type(e).__name__)[:160],'kind':'robots'})

            async def discover_sitemap():
                maps=list(dict.fromkeys((self.robots.site_maps() or []) if self.robots else []))+[urljoin(start,'/sitemap.xml')]
                found=[]
                for sm in list(dict.fromkeys(maps))[:2]:
                    if urlsplit(sm).hostname!=host:continue
                    if self.robots and not self.robots.can_fetch(AGENT,sm):continue
                    try:
                        raw,_,_,_=await self.fetch(client,sm,1_000_000)
                        xml=BeautifulSoup(raw,'xml')
                        for loc in xml.find_all('loc')[:400]:
                            try:u=clean_url(loc.get_text(strip=True))
                            except ValueError:continue
                            if urlsplit(u).hostname==host and not u.endswith('.xml'):found.append(u)
                    except Exception:pass
                return found

            sitemap_task=asyncio.create_task(discover_sitemap())
            def enqueue(url,depth,cats):
                if url in visited:return
                if url in frontier:
                    old_depth,old_cats=frontier[url]
                    frontier[url]=(min(old_depth,depth),sorted(set(old_cats+cats)))
                else:frontier[url]=(depth,cats)

            async def page_request(url):
                raw,ctype,final,enc=await self.fetch(client,url)
                if 'html' not in ctype and 'text/plain' not in ctype:return None,final
                p=await asyncio.to_thread(extract_html,raw.decode(enc,errors='replace'),final)
                p['fetched_at']=datetime.now().astimezone().isoformat()
                p['text_sha256']=hashlib.sha256(p['text'].encode()).hexdigest()
                return p,final

            try:
                while (frontier or pending or sitemap_task) and not self.cancel():
                    if sitemap_task and sitemap_task.done():
                        for u in sitemap_task.result():
                            if any(urlsplit(u).path.lower().endswith(e) for e in DOC_EXT):continue
                            enqueue(u,1,classify('',u))
                        sitemap_task=None
                    covered={s for p in self.pages for s in p['sections']}
                    counts={s:sum(s in p['sections'] for p in self.pages) for s in SECTIONS}
                    def priority(item):
                        url,(depth,cats)=item
                        return (0 if depth==0 else 1,0 if set(cats)-covered else 1,
                            min((counts[s]/quotas.get(s,3) for s in cats),default=5),depth)
                    candidates=sorted(frontier.items(),key=priority)
                    for url,(depth,cats) in candidates:
                        if len(pending)>= (parallel if self.pages else 1):break
                        if len(self.pages)+len(pending)>=max_pages or len(visited)>=max_pages*3+20:break
                        frontier.pop(url,None)
                        if url in visited:continue
                        visited.add(url)
                        if self.robots and not self.robots.can_fetch(AGENT,url):
                            self.errors.append({'url':url,'error':'Обход запрещён robots.txt','kind':'robots'});continue
                        task=asyncio.create_task(page_request(url));pending[task]=(url,depth,cats)
                    if not pending:
                        if sitemap_task:
                            await asyncio.wait([sitemap_task],return_when=asyncio.FIRST_COMPLETED);continue
                        break
                    finished,_=await asyncio.wait(list(pending),return_when=asyncio.FIRST_COMPLETED)
                    for task in finished:
                        url,depth,cats=pending.pop(task)
                        try:
                            p,final=task.result()
                            if not self.pages and depth==0:host=urlsplit(final).hostname
                            if urlsplit(final).hostname!=host:raise ValueError('Перенаправление за пределы сайта')
                            if p is None:continue
                            p['sections']=sorted(set(p['sections']+cats));self.pages.append(p)
                            for link in p['links']:
                                u=link['url'];path=urlsplit(u).path.lower()
                                if any(path.endswith(e) for e in DOC_EXT):
                                    if u not in document_urls:
                                        self.documents.append(dict(link,label=link['text'],source=p['url']));document_urls.add(u)
                                    continue
                                if urlsplit(u).hostname!=host or re.search(r'\.(jpg|png|jpeg|svg|webp|mp4|zip|rar|css|js)$',path):continue
                                keys=[k.lower() for k,v in parse_qsl(urlsplit(u).query)]
                                if keys and not all(k in ('page','p','pageno') or k.startswith('pagen_') for k in keys):continue
                                hints=classify(link['text'],u)
                                parent=urlsplit(p['url']).path.rstrip('/')+'/'
                                if parent!='/' and urlsplit(u).path.startswith(parent):
                                    hints=sorted(set(hints+[s for s in p['sections'] if s in ('news','events','staff')]))
                                if u in frontier or depth<self.cfg['max_depth']:enqueue(u,depth+1,hints)
                        except Exception as e:
                            self.errors.append({'url':url,'error':(str(e) or type(e).__name__)[:240],'kind':'fetch'})
                    self._notify(f'Страницы · {len(self.pages)} / {max_pages}')
                self.limited=bool(frontier or pending)
            finally:
                for task in pending:task.cancel()
                if sitemap_task:sitemap_task.cancel()
                await asyncio.gather(*pending,*([sitemap_task] if sitemap_task else []),return_exceptions=True)
            self.metrics['page_seconds']=round(time.perf_counter()-started,2)
            if self.checkpoint and self.pages:await self.checkpoint(self.snapshot())

            docs_started=time.perf_counter()
            max_documents=max(0,int(self.cfg.get('max_documents',20)))
            targets=self.documents[:max_documents]
            for d in self.documents[max_documents:]:d['state']='deferred'
            semaphore=asyncio.Semaphore(parallel)
            completed=0
            async def read(d):
                nonlocal completed
                async with semaphore:
                    if self.cancel():return
                    await self._read_document(client,d,host)
                    completed+=1;self._notify(f'Документы · {completed} / {len(targets)}')
            await asyncio.gather(*(read(d) for d in targets))
            self.metrics['document_seconds']=round(time.perf_counter()-docs_started,2)
        self.metrics['total_seconds']=round(time.perf_counter()-started,2)
        return self.snapshot()

