import asyncio
import csv
import html
import io
import json
import os
import secrets
import uuid
import time
import re
from contextlib import asynccontextmanager
from datetime import datetime,timedelta
from pathlib import Path
from urllib.parse import urlsplit
from fastapi import FastAPI,HTTPException,Request
from fastapi.responses import FileResponse,HTMLResponse,Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel,Field
from . import store
from .crawler import Crawler,clean_url
from .intelligence import analyze,models,complete
from .rules import audit,LOCAL

TASKS={}; CANCEL=set(); SESSION=secrets.token_urlsafe(32)

class Organization(BaseModel):
    name:str=Field(min_length=3,max_length=350)
    url:str=Field(max_length=2000)
    kind:str

class RunInput(BaseModel):
    organization_ids:list[int]=Field(default_factory=list,max_length=300)
    mode:str='full'

class SettingsInput(BaseModel):
    base_url:str='http://localhost:11434/v1'
    model:str=Field(default='',max_length=250)
    api_key:str|None=None
    llm_enabled:bool=False
    max_pages:int=Field(default=60,ge=10,le=300)
    max_depth:int=Field(default=4,ge=1,le=8)
    concurrency:int=Field(default=3,ge=1,le=8)
    page_concurrency:int=Field(default=4,ge=1,le=6)
    max_documents:int=Field(default=20,ge=0,le=50)
    request_delay:float=Field(default=0.4,ge=0.2,le=10)
    timeout:int=Field(default=18,ge=5,le=90)
    schedule_enabled:bool=False
    schedule_hour:int=Field(default=8,ge=0,le=23)
    schedule_interval_days:int=Field(default=7,ge=1,le=30)
    external_sources:list[str]=Field(default_factory=list,max_length=6)
    search_enabled:bool=True
    benchmark_school:int|None=None
    benchmark_kindergarten:int|None=None

def safe_settings(body):
    vals=body.model_dump(exclude={'api_key'})
    p=urlsplit(vals['base_url'])
    if p.scheme not in ('http','https') or not p.hostname or p.username or p.password or p.query or p.fragment:
        raise HTTPException(422,'Некорректный адрес API. Укажите http(s)://сервер:порт/v1')
    vals['base_url']=vals['base_url'].rstrip('/')
    try: vals['external_sources']=[clean_url(u) for u in vals['external_sources'] if u.strip()]
    except ValueError as e: raise HTTPException(422,str(e))
    if body.api_key is not None: vals['api_key']=body.api_key
    return vals

async def execute(run_id,orgs,config):
    semaphore=asyncio.Semaphore(config['concurrency'])
    with store.connect() as db:db.execute("UPDATE runs SET status='running' WHERE id=?",(run_id,))
    async def one(org):
        async with semaphore:
            if run_id in CANCEL:return
            started=time.perf_counter()
            match=re.search(r'["«]([^"»]+)["»]',org['name'])
            label=match[1] if match else org['name'][:85]
            def progress(n,url):
                stage=url if not url.startswith(('http://','https://')) else f'Страницы · {n}'
                with store.connect() as db:db.execute('UPDATE runs SET current=? WHERE id=?',(label+' / '+stage,run_id))
            def save(result):
                with store.connect() as db:
                    db.execute('INSERT INTO reports(run_id,org_id,created,data,summary) VALUES(?,?,?,?,?) ON CONFLICT(run_id,org_id) DO UPDATE SET data=excluded.data,summary=excluded.summary',
                        (run_id,org['id'],store.now(),json.dumps(result,ensure_ascii=False),json.dumps(store.summarize(result),ensure_ascii=False)))
            async def checkpoint(crawl):
                result=audit(org,crawl,{'state':'pending','findings':[],'events':[]})
                result.update(preliminary=True,status='processing',mode=config.get('mode','full'),metrics=dict(crawl.get('metrics',{})))
                save(result)
            try:
                crawl=await Crawler(config,lambda:run_id in CANCEL,progress,checkpoint).crawl(org['url'])
                if run_id in CANCEL:return
                progress(len(crawl['pages']),'Смысловой анализ' if config.get('llm_enabled') else 'Подготовка отчёта')
                ai=await analyze(crawl,config,org['kind'])
                if run_id in CANCEL:return
                result=audit(org,crawl,ai)
                result.update(preliminary=False,mode=config.get('mode','full'),metrics=dict(crawl.get('metrics',{}),total_seconds=round(time.perf_counter()-started,2)))
                save(result)
            except Exception as e:
                result=audit(org,{'pages':[],'documents':[],'errors':[{'url':org['url'],'error':str(e)[:300],'kind':'internal'}],'limited':False},{'state':'error','error':str(e)[:300]})
                with store.connect() as db:db.execute('INSERT OR REPLACE INTO reports(run_id,org_id,created,data) VALUES(?,?,?,?)',(run_id,org['id'],store.now(),json.dumps(result,ensure_ascii=False)))
            with store.connect() as db:db.execute('UPDATE runs SET done=done+1 WHERE id=?',(run_id,))
    try:
        await asyncio.gather(*(one(o) for o in orgs))
        status='cancelled' if run_id in CANCEL else 'completed'
        with store.connect() as db:db.execute('UPDATE runs SET status=?,finished=?,current=NULL WHERE id=?',(status,store.now(),run_id))
    except asyncio.CancelledError:
        store.finish_partial(run_id)
        with store.connect() as db:db.execute('UPDATE runs SET status=?,finished=?,current=NULL WHERE id=?',('cancelled' if run_id in CANCEL else 'interrupted',store.now(),run_id))
        raise
    finally:TASKS.pop(run_id,None);CANCEL.discard(run_id)

def start_run(ids=None,mode='full'):
    if TASKS:raise HTTPException(409,'Проверка уже выполняется. Дождитесь завершения или остановите её.')
    orgs=store.organizations()
    if ids:orgs=[o for o in orgs if o['id'] in ids]
    if not orgs:raise HTTPException(422,'Учреждения не выбраны')
    orgs=[{k:v for k,v in o.items() if k!='latest'} for o in orgs]
    if mode not in ('full','quick'):raise HTTPException(422,'Неизвестный режим проверки')
    config=store.settings(True);config['mode']=mode
    if mode=='quick':
        config.update(max_pages=min(config['max_pages'],24),max_documents=0,search_enabled=False,external_sources=[],llm_max_tokens=2500)
    rid=uuid.uuid4().hex[:12]
    with store.connect() as db:db.execute('INSERT INTO runs(id,created,status,total,options) VALUES(?,?,?,?,?)',(rid,store.now(),'queued',len(orgs),json.dumps({k:v for k,v in config.items() if k!='api_key'})))
    TASKS[rid]=asyncio.create_task(execute(rid,orgs,config))
    return {'id':rid,'total':len(orgs)}

def next_schedule(cfg,after=None):
    local=after or datetime.now(LOCAL)
    d=local.replace(hour=cfg['schedule_hour'],minute=0,second=0,microsecond=0)
    if d<=local:d+=timedelta(days=cfg['schedule_interval_days'])
    return d.isoformat()

async def scheduler():
    while True:
        await asyncio.sleep(20)
        cfg=store.settings(True)
        if not cfg['schedule_enabled']:continue
        if not cfg.get('next_run'):store.save_settings({'next_run':next_schedule(cfg)});continue
        if datetime.fromisoformat(cfg['next_run'])<=datetime.now(LOCAL) and not TASKS:
            start_run();store.save_settings({'next_run':next_schedule(cfg)})

@asynccontextmanager
async def lifespan(app):
    store.init(); task=asyncio.create_task(scheduler())
    yield
    task.cancel()
    for t in list(TASKS.values()):t.cancel()
    await asyncio.gather(task,*list(TASKS.values()),return_exceptions=True)

app=FastAPI(title='Север · мониторинг сайтов образования',version='1.0.0',lifespan=lifespan)
app.add_middleware(TrustedHostMiddleware,allowed_hosts=['localhost','127.0.0.1','[::1]','testserver'])

@app.middleware('http')
async def local_guard(request:Request,call_next):
    # Local service: protect mutation endpoints against cross-origin requests from other tabs.
    if request.method in ('POST','PUT','PATCH','DELETE'):
        origin=request.headers.get('origin')
        if origin and origin.rstrip('/')!=str(request.base_url).rstrip('/'):
            return Response('Недопустимый источник запроса',status_code=403)
        if request.headers.get('x-audit-session')!=SESSION:
            return Response('Обновите страницу приложения',status_code=403)
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['X-Frame-Options']='DENY'
    return response

@app.get('/api/state')
def state():
    with store.connect() as db:
        runs=[dict(r) for r in db.execute('SELECT * FROM runs ORDER BY created DESC LIMIT 30')]
        for r in runs:r.pop('options',None)
        reviews={r['fingerprint']:dict(r) for r in db.execute('SELECT * FROM reviews')}
    return {'organizations':store.organizations(),'runs':runs,'settings':store.settings(),'session':SESSION,'reviews':reviews,'time':store.now()}

@app.post('/api/organizations')
def add_org(body:Organization):
    if body.kind not in ('school','kindergarten'):raise HTTPException(422,'Выберите тип учреждения')
    try:url=clean_url(body.url)
    except ValueError as e:raise HTTPException(422,str(e))
    try:
        with store.connect() as db:
            c=db.execute('INSERT INTO organizations(name,url,kind) VALUES(?,?,?)',(body.name.strip(),url,body.kind))
            return {'id':c.lastrowid}
    except Exception:raise HTTPException(409,'Учреждение с таким адресом уже существует')

@app.post('/api/runs')
async def create_run(body:RunInput):return start_run(body.organization_ids,body.mode)

@app.post('/api/runs/{rid}/cancel')
async def cancel(rid:str):
    if rid not in TASKS:raise HTTPException(409,'Проверка уже завершена')
    CANCEL.add(rid)
    TASKS[rid].cancel()
    return {'status':'cancelling'}

@app.get('/api/reports')
def reports(org_id:int|None=None):
    with store.connect() as db:
        sql='SELECT id,run_id,org_id,created,summary FROM reports '+('WHERE org_id=? ' if org_id else '')+'ORDER BY id DESC LIMIT 400'
        rows=db.execute(sql,(org_id,) if org_id else ()).fetchall()
        result=[dict(store.row_summary(db,r),id=r['id'],org_id=r['org_id'],run_id=r['run_id'],created=r['created']) for r in rows]
    return result

@app.get('/api/reports/{report_id}')
def get_report(report_id:int):
    r=store.report(report_id)
    if not r:raise HTTPException(404,'Отчёт не найден')
    # Stored report is immutable; inspector marks are stored separately.
    with store.connect() as db:reviews={r['fingerprint']:dict(r) for r in db.execute('SELECT * FROM reviews')}
    r['reviews']=reviews;return r

class Review(BaseModel):
    state:str
    note:str=Field(default='',max_length=2000)

@app.put('/api/reviews/{fingerprint}')
def review(fingerprint:str,body:Review):
    if body.state not in ('open','confirmed','dismissed','fixed'):raise HTTPException(422,'Некорректный статус')
    with store.connect() as db:db.execute('INSERT OR REPLACE INTO reviews VALUES(?,?,?,?)',(fingerprint,body.state,body.note,store.now()))
    return {'ok':True}

@app.put('/api/settings')
def update_settings(body:SettingsInput):
    values=safe_settings(body)
    current=store.settings()
    if body.schedule_enabled and any(current[k]!=values[k] for k in ('schedule_enabled','schedule_hour','schedule_interval_days')):
        values['next_run']=next_schedule(values)
    elif not body.schedule_enabled:values['next_run']=None
    store.save_settings(values);return store.settings()

@app.post('/api/llm/test')
async def llm_test(body:SettingsInput):
    cfg=store.settings(True);cfg.update(safe_settings(body))
    try:
        found=await models(cfg)
        if not cfg['model'] and found:cfg['model']=found[0]
        result=await complete(cfg,[{'role':'system','content':'Return only valid JSON: {"ok": true}'},{'role':'user','content':'Проверка подключения'}])
        if not isinstance(result,dict):raise ValueError('Модель не вернула JSON объект')
        return {'ok':True,'models':found,'model':cfg['model'],'message':'Модель отвечает, JSON получен.'}
    except Exception as e:raise HTTPException(502,'Не удалось подключиться к модели: '+str(e)[:250])

def doc_categories(report):
    terms={'Устав':('устав','ustav'),'Лицензия':('лиценз','license','licenz'),'Аккредитация':('аккредитац','akkredit'),
        'Образовательная программа':('образовательн','программ'),'Самообследование':('самообслед','samoobsled'),
        'Правила приёма':('прием','приём','priema'),'Локальные акты':('локальн','lokal'),'Платные услуги':('платн','platn')}
    result=set()
    for d in report['documents']:
        text=(d.get('label',d.get('text','')[:180])+' '+d['url']).lower()
        for label,words in terms.items():
            if any(w in text for w in words):result.add(label)
    return result

@app.get('/api/comparison')
def comparison():
    records=store.latest_reports();cfg=store.settings();groups=[]
    for kind in ('school','kindergarten'):
        candidates=[r for r in records if r['data']['organization']['kind']==kind and r['data']['pages'] and not r['data'].get('preliminary')]
        eligible=[r for r in candidates if r['data']['coverage']>=60 and len(r['data']['pages'])>=5 and not r['data'].get('preliminary')]
        pinned=cfg['benchmark_'+kind]
        reference=next((r for r in candidates if r['org_id']==pinned),None)
        if not reference and eligible:reference=max(eligible,key=lambda r:(r['data']['coverage'],r['data']['score'] or 0))
        rows=[]
        for r in candidates:
            categories=doc_categories(r['data']);base=doc_categories(reference['data']) if reference else set()
            rows.append({'id':r['id'],'org_id':r['org_id'],'name':r['data']['organization']['name'],'score':r['data']['score'],
                'coverage':r['data']['coverage'],'documents':len(r['data']['documents']),'categories':sorted(categories),
                'missing_compared_to_reference':sorted(base-categories),'created':r['created']})
        groups.append({'kind':kind,'reference':{'id':reference['id'],'org_id':reference['org_id'],'name':reference['data']['organization']['name'],
            'categories':sorted(doc_categories(reference['data'])),'manual':bool(pinned),'created':reference['created']} if reference else None,
            'rows':sorted(rows,key=lambda r:(r['coverage'],r['score'] or 0),reverse=True)})
    return groups

def csv_value(value):
    s=str(value if value is not None else '')
    return "'"+s if s.lstrip().startswith(('=','+','-','@')) else s

@app.get('/api/export/summary.csv')
def export_summary():
    out=io.StringIO();w=csv.writer(out,delimiter=';');w.writerow(['Учреждение','Тип','Сайт','Дата проверки','Оценка проверенных пунктов','Охват %','Проблемы','Требуют проверки'])
    for o in store.organizations():
        l=o['latest'] or {};w.writerow([csv_value(v) for v in [o['name'],o['kind'],o['url'],l.get('created'),l.get('score'),l.get('coverage'),l.get('issues'),l.get('review')]])
    return Response('\ufeff'+out.getvalue(),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename=sever-summary.csv'})

@app.get('/api/reports/{report_id}/export/{format}')
def export_report(report_id:int,format:str):
    r=store.report(report_id)
    if not r:raise HTTPException(404,'Отчёт не найден')
    with store.connect() as db:
        marks={x['fingerprint']:dict(x) for x in db.execute('SELECT * FROM reviews')}
    r['reviews']={c['fingerprint']:marks[c['fingerprint']] for c in r['data']['checks'] if c['fingerprint'] in marks}
    d=r['data'];filename='sever-report-'+str(report_id)
    if format=='json':return Response(json.dumps(r,ensure_ascii=False,indent=2),media_type='application/json',headers={'Content-Disposition':f'attachment; filename={filename}.json'})
    if format=='csv':
        out=io.StringIO();w=csv.writer(out,delimiter=';');w.writerow(['Раздел','Вывод','Статус','Приоритет','Доказательство','Страница','Рекомендация','Метод','Решение инспектора','Комментарий','Дата решения','Режим проверки'])
        for c in d['checks']:
            mark=marks.get(c['fingerprint'],{})
            w.writerow([csv_value(c.get(k,'')) for k in ['section','title','status','severity','evidence','url','recommendation','method']]+[csv_value(mark.get(k,'')) for k in ['state','note','updated']]+['Быстрый обзор' if d.get('mode')=='quick' else 'Полная проверка'])
        return Response('\ufeff'+out.getvalue(),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename={filename}.csv'})
    if format!='html':raise HTTPException(404)
    e=lambda s:html.escape(str(s or ''))
    statuses={'pass':'Проверено','fail':'Проблема','review':'Требует проверки','unknown':'Нет данных'}
    priority={'high':'Высокий','medium':'Средний','low':'Низкий'}
    decisions={'open':'Открыто','confirmed':'Подтверждено','dismissed':'Не подтвердилось','fixed':'Исправлено'}
    mode_note='Быстрый обзор: файлы не скачивались, внешний факт-чекинг не выполнялся.' if d.get('mode')=='quick' else 'Полная проверка в пределах заданных лимитов.'
    if d.get('preliminary'):mode_note='ПРОМЕЖУТОЧНЫЙ ОТЧЁТ: проверка ещё продолжается. '+mode_note
    def decision(c):
        m=marks.get(c['fingerprint'])
        return '<br><b>Решение инспектора: '+e(decisions.get(m['state'],m['state']))+'</b><br>'+e(m.get('note'))+'<br>'+e(m.get('updated')) if m else ''
    rows=''.join(f'<tr><td>{e(c["section"])}</td><td><b>{e(c["title"])}</b><br>{statuses[c["status"]]} · {priority[c["severity"]]}{decision(c)}</td><td>{e(c["evidence"])}<br><a href="{e(c["url"])}">Страница</a></td><td>{e(c["recommendation"])}</td></tr>' for c in sorted(d['checks'],key=lambda c:({'high':0,'medium':1,'low':2}[c['severity']],c['status']=='pass')))
    docs=''.join(f'<li><a href="{e(x["url"])}">{e(x.get("label") or x.get("text", "")[:180] or x["url"])}</a> · {e(x.get("state","не загружен"))}</li>' for x in d['documents'])
    content=f'''<!doctype html><html lang="ru"><meta charset="utf-8"><title>Отчёт Север</title><style>body{{font:15px/1.6 Arial,sans-serif;color:#192e3b;margin:40px auto;max-width:1100px;padding:20px}}h1{{font-size:25px}}table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{border:1px solid #cbd2d5;padding:10px;text-align:left;vertical-align:top}}a{{color:#156b69;overflow-wrap:anywhere}}button{{padding:12px;background:#123d43;color:white;border:0}}@media print{{button{{display:none}}body{{margin:0;padding:0}}thead{{display:table-header-group}}tr{{break-inside:avoid}}}}@page{{size:A4 landscape;margin:12mm}}</style><button onclick="window.print()">Печать / Сохранить PDF</button><p>СЕВЕР / МОНИТОРИНГ САЙТОВ ОБРАЗОВАНИЯ</p><h1>{e(d['organization']['name'])}</h1><p>{e(d['organization']['url'])}<br>Проверка: {e(d['checked_at'])}<br>Охват подтверждённых проверок: {d['coverage']}%. Оценка проверенных пунктов: {e(d['score'])}/100. Страниц: {len(d['pages'])}.</p><p>{e(mode_note)}</p><p>Оценка относится только к подтверждённым пунктам. Вопросы для проверки и недоступные данные не означают нарушение.</p><table><thead><tr><th>Раздел</th><th>Вывод и приоритет</th><th>Основание</th><th>Что сделать</th></tr></thead><tbody>{rows}</tbody></table><h2>Перечень документов</h2><ul>{docs}</ul><h2>Ограничения</h2><ul>{''.join('<li>'+e(x)+'</li>' for x in d['limitations'])}</ul></html>'''
    return HTMLResponse(content,headers={'Content-Disposition':f'inline; filename={filename}.html'})

@app.get('/api/health')
def health():return {'status':'ok','version':'1.0.0'}

app.mount('/static',StaticFiles(directory=store.ROOT/'static'),name='static')
@app.get('/')
def index():return FileResponse(store.ROOT/'static'/'index.html')
