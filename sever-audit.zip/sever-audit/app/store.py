import json
import os
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('AUDIT_DATA_DIR', ROOT.parent / 'data'))
DATA.mkdir(parents=True, exist_ok=True)
DB = DATA / 'audit.sqlite3'

def now():
    return datetime.now(timezone.utc).isoformat()

def connect():
    db = sqlite3.connect(DB, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA journal_mode=WAL')
    return db

def init():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS organizations(id INTEGER PRIMARY KEY, name TEXT NOT NULL, url TEXT NOT NULL UNIQUE, kind TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, created TEXT NOT NULL, finished TEXT, status TEXT, total INTEGER, done INTEGER DEFAULT 0, current TEXT, error TEXT, options TEXT);
        CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY, run_id TEXT, org_id INTEGER, created TEXT, data TEXT, UNIQUE(run_id,org_id));
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS reviews(fingerprint TEXT PRIMARY KEY, state TEXT, note TEXT, updated TEXT);
        CREATE INDEX IF NOT EXISTS reports_org_latest ON reports(org_id,id DESC);
        ''')
        if 'summary' not in {r['name'] for r in db.execute('PRAGMA table_info(reports)')}:
            db.execute('ALTER TABLE reports ADD COLUMN summary TEXT')
        for row in db.execute('SELECT id,data FROM reports WHERE summary IS NULL').fetchall():
            db.execute('UPDATE reports SET summary=? WHERE id=?',(json.dumps(summarize(json.loads(row['data'])),ensure_ascii=False),row['id']))
        if db.execute('SELECT COUNT(*) FROM organizations').fetchone()[0] == 0:
            for o in json.loads((ROOT/'organizations.json').read_text(encoding='utf-8')):
                db.execute('INSERT OR IGNORE INTO organizations(name,url,kind) VALUES(?,?,?)',(o['name'],o['url'],o['kind']))
        db.execute("UPDATE runs SET status='interrupted',finished=?,error='Сервис был остановлен. Уже готовые отчёты сохранены; запустите новую проверку.' WHERE status IN ('queued','running')",(now(),))
        interrupted=[r['id'] for r in db.execute("SELECT id FROM runs WHERE status='interrupted'")]
    for rid in interrupted:finish_partial(rid)

def finish_partial(run_id):
    with connect() as db:
        for row in db.execute('SELECT id,data FROM reports WHERE run_id=?',(run_id,)).fetchall():
            d=json.loads(row['data'])
            if not d.get('preliminary'):continue
            d.update(preliminary=False,status='partial',interrupted=True)
            d['ai']={'state':'interrupted','findings':[],'events':[]}
            d['limitations'].append('Проверка остановлена после сбора страниц; чтение файлов и смысловой анализ могли не завершиться.')
            db.execute('UPDATE reports SET data=?,summary=? WHERE id=?',(json.dumps(d,ensure_ascii=False),json.dumps(summarize(d),ensure_ascii=False),row['id']))

def summarize(d):
    return {'name':d['organization']['name'],'score':d['score'],'coverage':d['coverage'],
        'issues':sum(c['status']=='fail' for c in d['checks']),'review':sum(c['status']=='review' for c in d['checks']),
        'status':d['status'],'pages':len(d['pages']),'preliminary':d.get('preliminary',False)}

def row_summary(db,row):
    if row['summary']:return json.loads(row['summary'])
    data=json.loads(db.execute('SELECT data FROM reports WHERE id=?',(row['id'],)).fetchone()['data'])
    summary=summarize(data)
    db.execute('UPDATE reports SET summary=? WHERE id=?',(json.dumps(summary,ensure_ascii=False),row['id']))
    return summary

DEFAULTS = {'base_url':'http://localhost:11434/v1','model':'','api_key':'','llm_enabled':False,
    'max_pages':60,'max_depth':4,'concurrency':3,'page_concurrency':4,'max_documents':20,'request_delay':0.4,'timeout':18,
    'schedule_enabled':False,'schedule_hour':8,'schedule_interval_days':7,'next_run':None,
    'external_sources':[],'search_enabled':True,'benchmark_school':None,'benchmark_kindergarten':None}

def settings(secret=False):
    result = dict(DEFAULTS)
    with connect() as db:
        result.update({r['key']:json.loads(r['value']) for r in db.execute('SELECT * FROM settings')})
    if os.getenv('LLM_API_KEY'): result['api_key'] = os.environ['LLM_API_KEY']
    if os.getenv('LLM_BASE_URL'): result['base_url'] = os.environ['LLM_BASE_URL']
    if os.getenv('LLM_MODEL'): result['model'] = os.environ['LLM_MODEL']
    if not secret:
        result['has_api_key'] = bool(result.pop('api_key',''))
    return result

def save_settings(values):
    with connect() as db:
        for key,value in values.items():
            if key in DEFAULTS:
                db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(key,json.dumps(value,ensure_ascii=False)))

def organizations():
    with connect() as db:
        rows=[dict(r) for r in db.execute('SELECT * FROM organizations ORDER BY id')]
        for o in rows:
            row=db.execute('SELECT id,created,summary FROM reports WHERE org_id=? ORDER BY id DESC LIMIT 1',(o['id'],)).fetchone()
            o['latest']=None
            if row:
                o['latest']=dict(row_summary(db,row),id=row['id'],created=row['created'])
    return rows

def report(report_id):
    with connect() as db:
        row=db.execute('SELECT * FROM reports WHERE id=?',(report_id,)).fetchone()
    if not row: return None
    r=dict(row); r['data']=json.loads(r['data']); return r

def latest_reports():
    with connect() as db:
        rows=db.execute('SELECT * FROM reports WHERE id IN (SELECT MAX(id) FROM reports GROUP BY org_id)').fetchall()
    return [dict(r, data=json.loads(r['data'])) for r in rows]
