import re
import hashlib
from datetime import datetime,timedelta,timezone
from dateutil.parser import isoparse

LABELS={'news':'Новости','events':'Мероприятия','documents':'Документы','schedule':'Расписание',
    'about':'О школе','structure':'Структура и органы управления','staff':'Педагогический состав',
    'contacts':'Контакты','programs':'Образовательные программы','employees':'Педагогам и сотрудникам','useful':'Полезная информация'}
MONTHS={'января':1,'февраля':2,'марта':3,'апреля':4,'мая':5,'июня':6,'июля':7,'августа':8,'сентября':9,'октября':10,'ноября':11,'декабря':12}
LOCAL=timezone(timedelta(hours=11))

def date_value(value):
    if not value: return None
    try:
        d=isoparse(value.strip())
        return d.replace(tzinfo=LOCAL) if d.tzinfo is None else d
    except (ValueError,TypeError): pass
    m=re.search(r'\b(\d{1,2})[.\-/](\d{1,2})[.\-/](20\d{2})\b',value)
    if m:
        try:return datetime(int(m[3]),int(m[2]),int(m[1]),tzinfo=LOCAL)
        except ValueError:return None
    m=re.search(r'\b(\d{1,2})\s+('+'|'.join(MONTHS)+r')\s+(20\d{2})\b',value.lower())
    if m:
        try:return datetime(int(m[3]),MONTHS[m[2]],int(m[1]),tzinfo=LOCAL)
        except ValueError:return None
    return None

def publication(p):
    values=list(dict.fromkeys(p.get('published',[])))
    if len(values)==1: return date_value(values[0]),values[0]
    m=re.search(r'(?:опубликовано|дата публикации)\s*:?\s*(\d{1,2}[.\-/]\d{1,2}[.\-/]20\d{2}|\d{1,2}\s+[а-я]+\s+20\d{2})',p['text'],re.I)
    if m:return date_value(m[1]),m[0]
    return None,''

def check(key,section,title,status='unknown',severity='medium',evidence='',url='',recommendation='',method='rule',**extra):
    return dict(key=key,section=section,title=title,status=status,severity=severity,evidence=evidence,url=url,
        recommendation=recommendation,method=method,**extra)

def audit(org,crawl,ai,at=None):
    at=at or datetime.now(LOCAL)
    pages=crawl['pages']; checks=[]
    required=['news','events','documents','schedule','about','structure','staff','contacts'] if org['kind']=='school' else ['news','documents','staff','contacts','programs','employees']
    sections={k:[p for p in pages if k in p['sections']] for k in LABELS}
    if not pages:
        checks.append(check('access','Доступность','Не удалось получить содержимое сайта','unknown','high',
            crawl['errors'][0]['error'] if crawl['errors'] else 'Нет доступных страниц',org['url'],
            'Проверьте доступность сайта и повторите проверку. Отсутствие содержимого не признано нарушением.'))
    for k in required:
        found=sections[k]
        readable=[p for p in found if len(p['text'])>=100]
        if readable:
            p=readable[0]; checks.append(check('section_'+k,LABELS[k],'Раздел найден и содержит текст','pass','low',p['text'][:240],p['url'],
                'Наличие текста не подтверждает полноту всех сведений.'))
        elif found:
            p=found[0]; checks.append(check('section_'+k,LABELS[k],'В полученной странице мало содержимого','review','medium',p['text'][:240] or 'Пустой текст страницы',p['url'],
                'Откройте раздел и проверьте заполнение, включая данные, загружаемые скриптами.'))
        else:
            checks.append(check('section_'+k,LABELS[k],'Раздел не обнаружен в пределах обхода','unknown','medium',
                f'Получено страниц: {len(pages)}. Лимит обхода: {"достигнут" if crawl["limited"] else "не достигнут"}.',org['url'],
                'Проверьте навигацию и наличие раздела вручную. При необходимости увеличьте глубину и лимит страниц.'))
    # Placeholder strings are exact observations, not inferred absence.
    patterns=['укажите цели и задачи','вводный текст на тему','документы не выбраны','демонстрационный контент','lorem ipsum','здесь будет ваш текст']
    for p in pages:
        for pattern in patterns:
            pos=p['text'].lower().find(pattern)
            if pos>=0:
                checks.append(check('placeholder_'+hashlib.sha1((p['url']+pattern).encode()).hexdigest()[:12],'Оформление',
                    'Обнаружена фраза, похожая на заглушку','review','medium',p['text'][max(0,pos-50):pos+170],p['url'],
                    'Замените текст-заглушку актуальными сведениями или скройте необязательный блок. Убедитесь, что это не цитата инструкции.'))
    news=[]
    for p in sections['news']:
        dt,quote=publication(p)
        if dt and dt<=at+timedelta(days=1): news.append((dt,p,quote))
    news.sort(key=lambda x:x[0],reverse=True)
    unique=[]
    for n in news:
        if not unique or n[0].date()!=unique[-1][0].date():unique.append(n)
    if unique:
        last,p,q=unique[0]; age=(at.date()-last.date()).days
        # A limited crawl can miss a more recent publication; therefore stale latest is review.
        checks.append(check('news_recent','Новости',f'Самая свежая найденная публикация: {last:%d.%m.%Y}',
            'review' if age>14 else 'pass','high' if age>14 else 'low',f'{q}. Прошло дней: {age}.',p['url'],
            'Проверьте, есть ли более свежие новости. Публикуйте новости с интервалом не более 14 дней.' if age>14 else 'Продолжайте обновлять новости не реже одного раза в 14 дней.'))
        gaps=[(a,b,(a[0].date()-b[0].date()).days) for a,b in zip(unique,unique[1:]) if (a[0].date()-b[0].date()).days>14]
        if gaps:
            a,b,gap=max(gaps,key=lambda x:x[2])
            checks.append(check('news_gap','Новости',f'Между найденными публикациями {gap} дней','review','high',
                f'{b[0]:%d.%m.%Y} → {a[0]:%d.%m.%Y}',a[1]['url'],
                'Проверьте архив за этот период: обход мог пропустить публикации. Если новостей нет, восстановите регулярность.',related_url=b[1]['url']))
        else: checks.append(check('news_gap','Новости','В выборке нет интервалов более 14 дней','pass' if len(unique)>1 else 'unknown','low',
            f'Найдено различных дат: {len(unique)}. Проверяется только полученная выборка.',p['url'],'Для проверки всего архива увеличьте лимит обхода.'))
    else:
        for key,title in [('news_recent','Не удалось установить дату последней новости'),('news_gap','Недостаточно дат для проверки интервалов')]:
            checks.append(check(key,'Новости',title,'unknown','medium','Однозначные даты публикации не найдены.',org['url'],'Проверьте даты в архиве новостей и доступность метаданных.'))
    timed=0
    for ev in ai.get('events',[]):
        pub=date_value(ev.get('published')); event=date_value(ev.get('event'))
        if not pub or not event or event>pub or not ev.get('verified_quote'): continue
        delta=pub-event
        precise=bool(re.search(r'\b\d{1,2}:\d{2}\b',ev.get('publication_quote','')) and re.search(r'\b\d{1,2}:\d{2}\b',ev.get('event_quote','')))
        timed+=1
        checks.append(check('news_24h_'+str(timed),'Новости',f'Событие и публикация: разница {delta.total_seconds()/3600:.0f} ч',
            'review','high' if delta>timedelta(hours=24) else 'low',ev['event_quote']+' / '+ev['publication_quote'],ev['url'],
            'Подтвердите извлечённые моделью даты. '+('При задержке более 24 часов скорректируйте процесс публикации.' if precise else 'Время суток не указано; точную задержку в 24 часа установить нельзя.'),method='llm'))
    if not timed:checks.append(check('news_24h','Новости','Срок 24 часа после события не установлен','unknown','medium',
        'Нет двух подтверждённых дат: события и публикации.',org['url'],'Укажите в публикации дату события. Для смыслового извлечения подключите модель; даты без времени требуют ручной проверки.'))
    if org['kind']=='school':
        quarter=(at.month-1)//3; start=datetime(at.year,quarter*3+1,1,tzinfo=LOCAL)
        nxt=datetime(at.year+1,1,1,tzinfo=LOCAL) if quarter==3 else datetime(at.year,(quarter+1)*3+1,1,tzinfo=LOCAL)
        end=datetime(nxt.year+1,1,1,tzinfo=LOCAL) if nxt.month==10 else datetime(nxt.year,nxt.month+3,1,tzinfo=LOCAL)
        for key,a,b in [('current',start,nxt),('next',nxt,end)]:
            candidates=[]
            for p in sections['events']:
                for m in re.finditer(r'\b\d{1,2}[.]\d{1,2}[.]20\d{2}\b|\b\d{1,2}\s+(?:'+'|'.join(MONTHS)+r')\s+20\d{2}\b',p['text'],re.I):
                    d=date_value(m[0])
                    if d and a<=d<b:candidates.append((p,m[0]))
            checks.append(check('events_'+key,'Мероприятия',f'План на {"текущий" if key=="current" else "следующий"} квартал ({a:%m.%Y}–{(b-timedelta(days=1)):%m.%Y})',
                'review' if candidates else 'unknown','medium', '; '.join(v for _,v in candidates[:6]) or 'Даты мероприятий этого квартала не обнаружены.',
                candidates[0][0]['url'] if candidates else org['url'],'Подтвердите, что найденные даты относятся к плану мероприятий, а не к архиву или дате публикации.'))
        checks.append(check('events_news','Мероприятия','Связь прошедших мероприятий с новостями','review' if sections['events'] and sections['news'] else 'unknown',
            'medium',f'Страниц мероприятий: {len(sections["events"])}; новостей: {len(sections["news"])}.',org['url'],
            'Сопоставьте название, дату и место прошедшего мероприятия с новостью. Смысловое сопоставление выполняет подключённая модель.'))
    for section,tests in [('contacts',[('phone',r'(?:\+7|8)[\s(\-]*\d[\d\s()\-]{8,18}','телефон'),('email',r'[\w.+-]+@[\w.-]+\.[a-zа-я]{2,}','электронная почта'),('hours',r'(?:режим работы|часы (?:работы|при[её]ма)|график работы)','режим работы и приём'),('address',r'(?:адрес|улица|ул\.|проспект|пер\.)','адрес')])]:
        targets=sections[section]+(pages[:1] if org['kind']=='kindergarten' else [])
        for key,pattern,label in tests:
            matches=[(p,re.search(pattern,p['text'],re.I)) for p in targets]
            matches=[(p,m) for p,m in matches if m]
            p,m=matches[0] if matches else (None,None)
            checks.append(check('contact_'+key,'Контакты',f'Контактные сведения: {label}','pass' if matches else 'review' if targets else 'unknown','medium',
                p['text'][max(0,m.start()-35):m.end()+110] if m else f'Поле «{label}» не распознано в полученном тексте.',p['url'] if p else org['url'],
                'Проверьте правильность и актуальность сведений.' if matches else f'Проверьте наличие поля «{label}» и заполните при отсутствии.'))
    docs=crawl['documents']
    checks.append(check('doc_inventory','Документы',f'Найдено ссылок на документы: {len(docs)}','pass' if docs else 'unknown','low',
        '; '.join(d.get('label') or d.get('text','')[:180] or d['url'].rsplit('/',1)[-1] for d in docs[:8]) or 'Ссылки на файлы не обнаружены.',org['url'],
        'Перечень доступен в отчёте. Сравнение с эталоном показывает различия, которые требуют проверки применимости.'))
    for d in docs:
        if d.get('state')=='error':checks.append(check('doc_'+hashlib.sha1(d['url'].encode()).hexdigest()[:10],'Документы',
            'Файл вернул HTTP '+str(d['http_status']) if d.get('http_status') in (404,410) else 'Не удалось скачать или прочитать документ',
            'fail' if d.get('http_status') in (404,410) else 'review','medium',d.get('error',''),d['url'],'Проверьте, открывается ли файл у посетителя; восстановите файл или исправьте ссылку.'))
    if org['kind']=='school' and pages:
        pos=any('pos.gosuslugi.ru' in l['url'] or 'pos.gosuslugi.ru' in l.get('text','') for l in pages[0]['links'])
        checks.append(check('pos','Главная страница','Баннер обратной связи ПОС','pass' if pos else 'review','low',
            'Найдена ссылка на pos.gosuslugi.ru' if pos else 'Ссылка ПОС не обнаружена в статической разметке.',pages[0]['url'],
            'Проверьте видимость баннера в браузере: он может добавляться скриптом.'))
    # Explicitly cover semantic requirements even when the LLM is disabled.
    for key,section,title in [('staff_fields','Педагогический состав','Фото, образование и контакты каждого сотрудника'),
        ('visual','Оформление','Качество фото, единообразие шрифтов и отсутствие наложений')]:
        checks.append(check(key,section,title,'review' if key=='visual' else 'unknown','low' if key=='visual' else 'medium',
            'Текстовый обход не подтверждает визуальные характеристики.' if key=='visual' else 'Требуется анализ индивидуальных карточек.',org['url'],
            'Откройте страницы в браузере и выполните визуальную проверку.' if key=='visual' else 'Подключите модель для анализа карточек, затем подтвердите выводы.'))
    for i,f in enumerate(ai.get('findings',[])):
        checks.append(dict(f,key='ai_'+str(i)))
    total=len(checks); assessed=sum(c['status'] in ('pass','fail') for c in checks)
    passes=sum(c['status']=='pass' for c in checks)
    score=round(100*passes/assessed) if assessed else None
    for c in checks:
        c['fingerprint']=hashlib.sha256((str(org['id'])+c['key']+c['title']+c['evidence']).encode()).hexdigest()[:24]
    return {'organization':org,'checked_at':at.isoformat(),'status':'unavailable' if not pages else 'partial' if crawl['limited'] or crawl['errors'] else 'complete',
        'score':score,'coverage':round(100*assessed/total) if total else 0,'checks':checks,'pages':pages,'documents':docs,
        'errors':crawl['errors'],'limited':crawl['limited'],'ai':ai,'news_dates':[{'date':n[0].isoformat(),'url':n[1]['url'],'evidence':n[2]} for n in unique],
        'limitations':['Обход статической HTML-разметки; содержимое после выполнения JavaScript может быть пропущено.',
            'Сканированные PDF без текстового слоя и старые DOC требуют ручной проверки.',
            'Отсутствие сведений в выборке не является доказательством отсутствия на всём сайте.',
            'Оценка отражает проверенные пункты; охват показан отдельно. Это не заключение о соблюдении закона.']}
