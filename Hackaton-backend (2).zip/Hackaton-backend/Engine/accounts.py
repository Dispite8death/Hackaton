"""Local operator accounts and expiring sessions for the loopback dashboard."""
import hashlib
import hmac
import json
import secrets
from http.cookies import CookieError, SimpleCookie
from pathlib import Path

COOKIE = "audit_operator"
LIFETIME = 12 * 60 * 60
ITERATIONS = 600_000


def initialize(conn):
    account = json.loads(Path(__file__).with_name("operator.json").read_text(encoding="utf-8"))
    with conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS audit_user(
            username TEXT PRIMARY KEY, salt BLOB NOT NULL, verifier BLOB NOT NULL)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS audit_session(
            digest BLOB PRIMARY KEY, username TEXT NOT NULL REFERENCES audit_user(username),
            expires INTEGER NOT NULL)""")
        conn.execute("INSERT OR IGNORE INTO audit_user VALUES(?,?,?)",
                     (account["username"], bytes.fromhex(account["salt"]), bytes.fromhex(account["verifier"])))


def _digest(raw_cookie):
    cookie = SimpleCookie()
    try:
        cookie.load(raw_cookie)
    except CookieError:
        return None
    value = cookie.get(COOKIE)
    if value and len(value.value) == 43 and value.value.isascii():
        return hashlib.sha256(value.value.encode()).digest()
    return None


def session_user(conn, raw_cookie):
    digest = _digest(raw_cookie)
    if digest is None:
        return None
    row = conn.execute("SELECT username FROM audit_session WHERE digest=? AND expires>unixepoch()", (digest,)).fetchone()
    return row[0] if row else None


def login(conn, username, password, raw_cookie):
    if not isinstance(username,str) or not isinstance(password,str) or len(username)>80 or len(password)>256:
        return None
    row = conn.execute("SELECT salt,verifier FROM audit_user WHERE username=?", (username,)).fetchone()
    computed = hashlib.pbkdf2_hmac("sha256",password.encode(),row[0] if row else bytes(16),ITERATIONS)
    if row is None or not hmac.compare_digest(computed,row[1]):
        return None
    token = secrets.token_urlsafe(32)
    with conn:
        conn.execute("DELETE FROM audit_session WHERE expires<=unixepoch() OR digest=?", (_digest(raw_cookie),))
        conn.execute("INSERT INTO audit_session VALUES(?,?,unixepoch()+?)",
                     (hashlib.sha256(token.encode()).digest(),username,LIFETIME))
    return f"{COOKIE}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={LIFETIME}"


def logout(conn, raw_cookie):
    with conn:
        conn.execute("DELETE FROM audit_session WHERE digest=?", (_digest(raw_cookie),))
    return f"{COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"
