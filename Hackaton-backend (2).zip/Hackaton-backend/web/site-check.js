(() => {
  "use strict";

  const start = document.getElementById("start-check");
  const selected = document.getElementById("start-selected");
  const status = document.getElementById("check-status");
  const path = "/api/admin/site-check";
  let token;
  let timer;
  let tracking = false;

  let selection = {ids: [], card: false};
  function updateSelectionButton() {
    const count = selection.ids.length;
    selected.disabled = start.disabled || count === 0;
    selected.textContent = selection.card ? "Проверить сайт" :
      (count ? "Проверить выбранные (" + count + ")" : "Проверить выбранные");
  }
  window.addEventListener("audit-selection", event => {
    selection = event.detail;
    updateSelectionButton();
  });

  function poll(delay) {
    clearTimeout(timer);
    timer = setTimeout(readStatus, delay);
  }

  function show(job) {
    const running = job.state === "running";
    start.disabled = running;
    updateSelectionButton();
    start.textContent = running ? "Идёт проверка…" : "Проверить все сайты";
    const count = job.processed == null ? "" :
      " Обработано сайтов: " + job.processed + (job.total == null ? "" : " из " + job.total) + ".";
    const messages = {
      idle: "",
      running: job.current ? "Проверяем: " + job.current + "." + count :
        (job.processed == null ? "Запускается проверка сайтов…" : "Обрабатываем материалы проверки." + count),
      completed: "Проверка завершена." + count,
      partial: "Проверка завершена частично." + count,
      busy: "Уже выполняется другой цикл. Повторите запуск после его завершения.",
      error: "Не удалось выполнить проверку."
    };
    status.textContent = (messages[job.state] || "Проверка остановлена.") + (job.error ? " " + job.error : "") +
      (job.started_by ? " Пользователь: " + job.started_by + "." : "");
    if (running) {
      tracking = true;
      poll(2500);
    } else if (tracking) {
      tracking = false;
      window.dispatchEvent(new Event("audit-finished"));
    }
  }

  async function readStatus() {
    try {
      const response = await fetch(path);
      if (!response.ok) throw Error();
      const result = await response.json();
      token = result.token;
      show(result.job);
    } catch {
      start.disabled = selected.disabled = true;
      status.textContent = "Нет связи с локальным сервером. Повторяем запрос состояния…";
      poll(5000);
    }
  }

  async function launch(event) {
    const button = event.currentTarget;
    if (!token || button.disabled) return;
    const payload = {};
    if (button === selected) {
      const ids = selection.ids;
      if (!ids.length || !ids.every(id => Number.isSafeInteger(id) && id > 0)) return;
      payload.organization_ids = [...ids];
    }
    start.disabled = selected.disabled = true;
    tracking = true;
    status.textContent = button === selected ? "Запускаем проверку отмеченных учреждений…" : "Запускаем проверку всех сайтов реестра…";
    try {
      const response = await fetch(path, {
        method: "POST",
        headers: {"Content-Type": "application/json", "X-Audit-Token": token},
        body: JSON.stringify(payload)
      });
      const result = await response.json();
      if (!response.ok) {
        await readStatus();
        if (!start.disabled) status.textContent = result.error || "Не удалось начать проверку.";
        return;
      }
      show(result);
    } catch {
      status.textContent = "Связь прервалась. Уточняем, запущена ли проверка…";
      poll(1000);
    }
  }
  start.addEventListener("click", launch);
  selected.addEventListener("click", launch);

  window.addEventListener("audit-access", event => {
    if (event.detail) {
      readStatus();
    } else {
      start.disabled = selected.disabled = true;
      status.textContent = "Для запуска проверки откройте приложение через start.cmd (Windows) или start.sh на компьютере с сервером.";
    }
  });
})();
