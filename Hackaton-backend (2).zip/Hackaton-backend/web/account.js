(() => {
  "use strict";
  const get = id => document.getElementById(id);
  const action = get("account-action");
  const dialog = get("login-dialog");
  const form = get("login-form");
  let token, user;

  function display(name) {
    user = name;
    get("access").textContent = user || "Локальный доступ";
    action.textContent = user ? "Выйти" : "Войти";
    action.hidden = false;
  }

  async function submit(path, payload) {
    const response = await fetch("/api/admin/" + path, {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-Audit-Token": token},
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw Error(result.error || "Не удалось выполнить запрос.");
    display(result.user);
  }

  window.addEventListener("audit-account", event => {
    if (!event.detail.admin) return;
    token = event.detail.token;
    display(event.detail.user);
  });

  action.addEventListener("click", async () => {
    if (user) {
      action.disabled = true;
      try { await submit("logout", {}); }
      catch { window.alert("Не удалось выйти. Проверьте соединение и повторите."); }
      finally { action.disabled = false; }
      return;
    }
    get("login-error").textContent = "";
    dialog.showModal();
    form.elements.password.focus();
  });
  get("close-login").addEventListener("click", () => dialog.close());
  dialog.addEventListener("close", () => { form.elements.password.value = ""; });
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const button = form.querySelector("[type=submit]");
    if (button.disabled) return;
    button.disabled = true;
    try {
      await submit("login", Object.fromEntries(new FormData(form)));
      dialog.close();
    } catch (error) {
      get("login-error").textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });
})();
